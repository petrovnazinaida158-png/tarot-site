const escapeHtml = (value = "") =>
  String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;");

exports.handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method not allowed" };
  }

  const token = process.env.TELEGRAM_BOT_TOKEN;
  const chatId = process.env.TELEGRAM_CHAT_ID;

  if (!token || !chatId) {
    console.error("Missing TELEGRAM_BOT_TOKEN or TELEGRAM_CHAT_ID");
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Telegram environment variables are not configured" })
    };
  }

  try {
    const data = JSON.parse(event.body || "{}");

    const lines = [
      "🔮 <b>НОВЫЙ БЕСПЛАТНЫЙ ВОПРОС</b>",
      "",
      `👤 <b>Имя:</b> ${escapeHtml(data.name || "Не указано")}`,
      `🎂 <b>Дата рождения / возраст:</b> ${escapeHtml(data.birth || "Не указано")}`,
      `🌍 <b>Страна:</b> ${escapeHtml(data.country || "Не указано")}`,
      `📱 <b>Контакт:</b> ${escapeHtml(data.contact || "Не указано")}`,
      "",
      "❓ <b>Главный вопрос:</b>",
      escapeHtml(data.question || "Не указан"),
      "",
      `❤️ <b>Вопрос связан с другим человеком:</b> ${escapeHtml(data.other_person || "Не указано")}`
    ];

    if (data.other_person === "Да") {
      lines.push(
        `👤 <b>Имя человека:</b> ${escapeHtml(data.person_name || "Не указано")}`,
        `🎂 <b>Дата рождения:</b> ${escapeHtml(data.person_birth || "Не указано")}`,
        `🔗 <b>Кем приходится:</b> ${escapeHtml(data.relation || "Не указано")}`
      );
    }

    const response = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        chat_id: chatId,
        text: lines.join("\n"),
        parse_mode: "HTML",
        disable_web_page_preview: true
      })
    });

    const result = await response.json();

    if (!response.ok || !result.ok) {
      console.error("Telegram API error:", result);
      return {
        statusCode: 502,
        body: JSON.stringify({ error: "Telegram API request failed" })
      };
    }

    return {
      statusCode: 200,
      body: JSON.stringify({ ok: true })
    };
  } catch (error) {
    console.error("Function error:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Internal server error" })
    };
  }
};
